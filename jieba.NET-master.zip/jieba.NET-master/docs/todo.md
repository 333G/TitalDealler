1. Deploy dicts with dlls?
2. Spell check and suggests
3. News Classification
4. Synonyms
5. Parallel

Misc
1. cache;
2. other dict files;
3. multiple english words (e.g. Steve Jobs)
4. named entity recognition
5. new word recognition
6. logging
7. Pinyin
8. Simplified <-> Traditional

Ideas
1. [linggle](http://linggle.com/)
2. gensim